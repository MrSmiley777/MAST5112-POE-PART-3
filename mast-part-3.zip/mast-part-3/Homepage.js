import React from 'react';
import { View, Text, Button, FlatList, StyleSheet, ImageBackground } from 'react-native';

const foodImage = require('./assets/Food.jpg');

const calculateAveragePrice = (menuItems, course) => {
  const filteredItems = menuItems.filter(item => item.course === course);
  const total = filteredItems.reduce((sum, item) => sum + parseFloat(item.price), 0);
  return filteredItems.length ? `R${(total / filteredItems.length).toFixed(2)}` : 'R0.00';
};

export default function HomeScreen({ navigation, menuItems }) {
  return (
    <ImageBackground source={foodImage} style={styles.background}>
      <View style={styles.overlay}>
        <Text style={styles.title}>Menu</Text>

        <Text style={styles.averagePrice}>Starters Average Price: {calculateAveragePrice(menuItems, 'Starters')}</Text>
        <Text style={styles.averagePrice}>Mains Average Price: {calculateAveragePrice(menuItems, 'Mains')}</Text>
        <Text style={styles.averagePrice}>Dessert Average Price: {calculateAveragePrice(menuItems, 'Dessert')}</Text>

        <FlatList
          data={menuItems}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.menuItem}>
              <Text style={styles.menuItemText}>{item.dishName}</Text>
              <Text style={styles.menuItemText}>{item.description}</Text>
              <Text style={styles.menuItemText}>{item.course}</Text>
              <Text style={styles.menuItemText}>R{item.price}</Text>
            </View>
          )}
        />

        <Button title="Add Menu Item" onPress={() => navigation.navigate('Manage Menu')} />
        <Button title="Filter Menu" onPress={() => navigation.navigate('Filter Menu')} />
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: 20,
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    marginVertical: 20,
    color: '#333',
    fontWeight: 'bold',
  },
  averagePrice: {
    fontSize: 16,
    color: '#555',
    marginVertical: 5,
  },
  menuItem: {
    padding: 10,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginVertical: 5,
    backgroundColor: '#fff',
  },
  menuItemText: {
    color: '#333',
  },
});



