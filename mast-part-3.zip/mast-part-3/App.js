import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './Homepage';
import AddMenuItemScreen from './Menu';
import FilterMenuScreen from './Filter';

const Stack = createStackNavigator();

export default function App() {
  const [menuItems, setMenuItems] = useState([]);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home">
          {props => (
            <HomeScreen {...props} menuItems={menuItems} />
          )}
        </Stack.Screen>
        <Stack.Screen name="Manage Menu">
          {props => (
            <AddMenuItemScreen 
              {...props} 
              menuItems={menuItems} 
              setMenuItems={setMenuItems} 
            />
          )}
        </Stack.Screen>
        <Stack.Screen name="Filter Menu">
          {props => (
            <FilterMenuScreen {...props} menuItems={menuItems} />
          )}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}










