import React, { useState } from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';

export default function FilterMenuScreen({ menuItems }) { 
  const [selectedCourse, setSelectedCourse] = useState('All');

  const filteredItems = selectedCourse === 'All'
    ? menuItems
    : menuItems.filter(item => item.course === selectedCourse);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Filter Menu by Course</Text>

      <Button title="All" onPress={() => setSelectedCourse('All')} /> 
      <Button title="Starters" onPress={() => setSelectedCourse('Starters')} />
      <Button title="Mains" onPress={() => setSelectedCourse('Mains')} />
      <Button title="Dessert" onPress={() => setSelectedCourse('Dessert')} />

      <FlatList
        data={filteredItems}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.menuItem}>
            <Text>{item.dishName}</Text>
            <Text>{item.description}</Text>
            <Text>{item.course}</Text>
            <Text>R{item.price}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 24, textAlign: 'center', marginVertical: 20 },
  menuItem: { padding: 10, borderColor: 'gray', borderWidth: 1, marginVertical: 5 }
});



