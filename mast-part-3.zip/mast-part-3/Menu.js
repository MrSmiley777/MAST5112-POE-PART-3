import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, TouchableOpacity } from 'react-native';

export default function AddMenuItemScreen({ menuItems, setMenuItems }) { 
  const [dishName, setDishName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState('Starters');
  const [price, setPrice] = useState('');

  const handleAddItem = () => {
    if (dishName && description && price) { 
      const newItem = { id: Math.random().toString(), dishName, description, course, price };
      setMenuItems([...menuItems, newItem]);
      setDishName('');
      setDescription('');
      setPrice('');
    } else {
      alert('Please fill in all fields');
    }
  };

  const handleRemoveItem = (id) => {
    setMenuItems(menuItems.filter(item => item.id !== id));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add Menu Item</Text>
      
      <TextInput style={styles.input} placeholder="Dish Name" value={dishName} onChangeText={setDishName} /> 
      <TextInput style={styles.input} placeholder="Description" value={description} onChangeText={setDescription} />
      
      <TouchableOpacity onPress={() => setCourse(course === 'Starters' ? 'Mains' : course === 'Mains' ? 'Dessert' : 'Starters')}>
        <Text style={styles.input}>{course} (Tap to cycle courses)</Text>
      </TouchableOpacity>

      <TextInput style={styles.input} placeholder="Price" keyboardType="numeric" value={price} onChangeText={setPrice} />
      
      <Button title="Add Item" onPress={handleAddItem} />

      <FlatList 
        data={menuItems}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.menuItem}>
            <Text>{item.dishName}</Text>
            <Text>{item.description}</Text>
            <Text>{item.course}</Text>
            <Text>R{item.price}</Text>
            <Button title="Remove" onPress={() => handleRemoveItem(item.id)} />
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 24, textAlign: 'center', marginVertical: 20 },
  input: { height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 10, paddingLeft: 10 },
  menuItem: { padding: 10, borderColor: 'gray', borderWidth: 1, marginVertical: 5 }
});





